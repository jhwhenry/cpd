#!/bin/bash
# This script assumes
# 1. oc command line tool available on path
# 2. oc login for required cluster is already executed
# 3. User is already on correct openshift namespace

set -e

RMQ_POD=$(oc get pods | grep rabbitmq | awk '{print $1}' 2>&1 | head -n 1)

oc exec "${RMQ_POD}" -- sh -c "rabbitmqctl list_queues | grep -E '^(cams-api-jobs-*|BG-update-event|CAMS-GSRelDoc-Project-Update-Event|CAMS-GSRelDoc-Space-Update-Event|gss_queue_resync_request)'" | awk '{print $1}' | while read queue_name; do
    echo "Start deleting RMQ queue ${queue_name}"
    oc exec "${RMQ_POD}" -- sh -c "rabbitmqctl delete_queue ${queue_name}"
    echo "Finished deleting RMQ queue ${queue_name}"
    echo
done

echo "Finished cleaning up RMQ queues for catalog-api-jobs."

echo "Restarting catalog-api-jobs pod"

oc scale deploy catalog-api-jobs  --replicas=0
oc scale deploy catalog-api-jobs --replicas=1

TIME_ELAPSED=0
 INTERVAL=10
 until [  -n "$IS_RUNNING" ] || [ $TIME_ELAPSED -ge 600 ]
 do
     sleep $INTERVAL
     TIME_ELAPSED=$(($TIME_ELAPSED + $INTERVAL))
     echo 'waiting for catalog-api-jobs pod to come up...'
     RUNNING_POD_NAME=$(oc get pods | grep catalog-api-jobs | grep "Running" | awk -F " " '{print $1}')
     CATALOG_API_JOB_POD_STATE=$(oc get pods | grep catalog-api-jobs)
     echo "$CATALOG_API_JOB_POD_STATE"
     IS_RUNNING=$(oc logs "$RUNNING_POD_NAME" |grep -i "Started AsyncUpdatePropagatorApp in")
 done

 echo "Finished Restarting catalog-api-jobs pod"
